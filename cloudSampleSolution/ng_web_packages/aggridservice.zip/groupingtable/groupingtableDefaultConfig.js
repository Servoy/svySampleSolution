angular.module('ngDataGrid',['servoy'])
.factory("ngDataGrid",function() 
{
	return {}
})
