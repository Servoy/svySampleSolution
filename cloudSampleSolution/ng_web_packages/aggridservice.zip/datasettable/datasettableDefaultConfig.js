angular.module('ngPowerGrid',['servoy'])
.factory("ngPowerGrid",function() 
{
	return {}
})